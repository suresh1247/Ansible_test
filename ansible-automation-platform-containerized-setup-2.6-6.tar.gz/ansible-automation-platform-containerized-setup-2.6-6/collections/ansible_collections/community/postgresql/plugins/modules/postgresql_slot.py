#!/usr/bin/python
# -*- coding: utf-8 -*-

# Copyright: (c) 2019, John Scalia (@jscalia), Andrew Klychkov (@Andersson007) <andrew.a.klychkov@gmail.com>
# GNU General Public License v3.0+ (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)

from __future__ import absolute_import, division, print_function

__metaclass__ = type

DOCUMENTATION = r'''
---
module: postgresql_slot
short_description: Add or remove replication slots from a PostgreSQL database
description:
- Add or remove physical or logical replication slots from a PostgreSQL database.

options:
  name:
    description:
    - Name of the replication slot to add or remove.
    type: str
    required: true
    aliases:
    - slot_name
  slot_type:
    description:
    - Slot type.
    type: str
    default: physical
    choices: [ logical, physical ]
  state:
    description:
    - The slot state.
    - I(state=present) implies the slot must be present in the system.
    - I(state=absent) implies the I(groups) must be revoked from I(target_roles).
    type: str
    default: present
    choices: [ absent, present ]
  immediately_reserve:
    description:
    - Optional parameter that when C(true) specifies that the LSN for this replication slot be reserved
      immediately, otherwise the default, C(false), specifies that the LSN is reserved on the first connection
      from a streaming replication client.
    - Is available from PostgreSQL version 9.6.
    - Uses only with I(slot_type=physical).
    - Mutually exclusive with I(slot_type=logical).
    type: bool
    default: false
  output_plugin:
    description:
    - All logical slots must indicate which output plugin decoder they're using.
    - This parameter does not apply to physical slots.
    - It will be ignored with I(slot_type=physical).
    type: str
    default: "test_decoding"
  login_db:
    description:
    - Name of database to connect to.
    - The V(db) alias is deprecated and will be removed in version 5.0.0.
    type: str
    aliases:
    - db
  session_role:
    description:
    - Switch to session_role after connecting.
      The specified session_role must be a role that the current login_user is a member of.
    - Permissions checking for SQL commands is carried out as though
      the session_role were the one that had logged in originally.
    type: str
  trust_input:
    description:
    - If C(false), check the value of I(session_role) is potentially dangerous.
    - It makes sense to use C(false) only when SQL injections via I(session_role) are possible.
    type: bool
    default: true
    version_added: '0.2.0'

notes:
- Physical replication slots were introduced to PostgreSQL with version 9.4,
  while logical replication slots were added beginning with version 10.0.

attributes:
  check_mode:
    support: full

seealso:
- name: PostgreSQL pg_replication_slots view reference
  description: Complete reference of the PostgreSQL pg_replication_slots view.
  link: https://www.postgresql.org/docs/current/view-pg-replication-slots.html
- name: PostgreSQL streaming replication protocol reference
  description: Complete reference of the PostgreSQL streaming replication protocol documentation.
  link: https://www.postgresql.org/docs/current/protocol-replication.html
- name: PostgreSQL logical replication protocol reference
  description: Complete reference of the PostgreSQL logical replication protocol documentation.
  link: https://www.postgresql.org/docs/current/protocol-logical-replication.html

author:
- John Scalia (@jscalia)
- Andrew Klychkov (@Andersson007)
- Thomas O'Donnell (@andytom)
extends_documentation_fragment:
- community.postgresql.postgres
'''

EXAMPLES = r'''
- name: Create physical_one physical slot if doesn't exist
  become_user: postgres
  community.postgresql.postgresql_slot:
    slot_name: physical_one
    login_db: ansible

- name: Remove physical_one slot if exists
  become_user: postgres
  community.postgresql.postgresql_slot:
    slot_name: physical_one
    db: ansible
    state: absent

- name: Create logical_one logical slot to the database acme if doesn't exist
  community.postgresql.postgresql_slot:
    name: logical_slot_one
    slot_type: logical
    state: present
    output_plugin: custom_decoder_one
    login_db: acme

- name: Remove logical_one slot if exists from the cluster running on another host and non-standard port
  community.postgresql.postgresql_slot:
    name: logical_one
    login_host: mydatabase.example.org
    port: 5433
    login_user: ourSuperuser
    login_password: thePassword
    state: absent
'''

RETURN = r'''
name:
  description: Name of the slot.
  returned: success
  type: str
  sample: "physical_one"
queries:
  description: List of executed queries.
  returned: success
  type: str
  sample: [ "SELECT pg_create_physical_replication_slot('physical_one', False, False)" ]
'''

from ansible.module_utils.basic import AnsibleModule
from ansible_collections.community.postgresql.plugins.module_utils.database import \
    check_input
from ansible_collections.community.postgresql.plugins.module_utils.postgres import (
    connect_to_db,
    ensure_required_libs,
    exec_sql,
    get_conn_params,
    get_server_version,
    pg_cursor_args,
    postgres_common_argument_spec,
)

# ===========================================
# PostgreSQL module specific support methods.
#


class PgSlot(object):
    def __init__(self, module, cursor, name):
        self.module = module
        self.cursor = cursor
        self.name = name
        self.exists = False
        self.kind = ''
        self.__slot_exists()
        self.changed = False
        self.executed_queries = []

    def create(self, kind='physical', immediately_reserve=False, output_plugin=False, just_check=False):
        if self.exists:
            if self.kind == kind:
                return False
            else:
                self.module.warn("slot with name '%s' already exists "
                                 "but has another type '%s'" % (self.name, self.kind))
                return False

        if just_check:
            return None

        if kind == 'physical':
            # Check server version (immediately_reserved needs 9.6+):
            if get_server_version(self.cursor.connection) < 90600:
                query = "SELECT pg_create_physical_replication_slot(%(name)s)"

            else:
                query = "SELECT pg_create_physical_replication_slot(%(name)s, %(i_reserve)s)"

            self.changed = exec_sql(self, query,
                                    query_params={'name': self.name, 'i_reserve': immediately_reserve},
                                    return_bool=True)

        elif kind == 'logical':
            query = "SELECT pg_create_logical_replication_slot(%(name)s, %(o_plugin)s)"
            self.changed = exec_sql(self, query,
                                    query_params={'name': self.name, 'o_plugin': output_plugin}, return_bool=True)

    def drop(self):
        if not self.exists:
            return False

        query = "SELECT pg_drop_replication_slot(%(name)s)"
        self.changed = exec_sql(self, query, query_params={'name': self.name}, return_bool=True)

    def __slot_exists(self):
        query = "SELECT slot_type FROM pg_replication_slots WHERE slot_name = %(name)s"
        res = exec_sql(self, query, query_params={'name': self.name}, add_to_executed=False)
        if res:
            self.exists = True
            self.kind = res[0]["slot_type"]


# ===========================================
# Module execution.
#


def main():
    argument_spec = postgres_common_argument_spec()
    argument_spec.update(
        login_db=dict(type='str', aliases=['db'], deprecated_aliases=[
            {
                'name': 'db',
                'version': '5.0.0',
                'collection_name': 'community.postgresql',
            }],
        ),
        name=dict(type="str", required=True, aliases=["slot_name"]),
        slot_type=dict(type="str", default="physical", choices=["logical", "physical"]),
        immediately_reserve=dict(type="bool", default=False),
        session_role=dict(type="str"),
        output_plugin=dict(type="str", default="test_decoding"),
        state=dict(type="str", default="present", choices=["absent", "present"]),
        trust_input=dict(type="bool", default=True),
    )

    module = AnsibleModule(
        argument_spec=argument_spec,
        supports_check_mode=True,
    )

    name = module.params["name"]
    slot_type = module.params["slot_type"]
    immediately_reserve = module.params["immediately_reserve"]
    state = module.params["state"]
    output_plugin = module.params["output_plugin"]

    if not module.params["trust_input"]:
        check_input(module, module.params['session_role'])

    if immediately_reserve and slot_type == 'logical':
        module.fail_json(msg="Module parameters immediately_reserve and slot_type=logical are mutually exclusive")

    # When slot_type is logical and parameter db is not passed,
    # the default database will be used to create the slot and
    # the user should know about this.
    # When the slot type is physical,
    # it doesn't matter which database will be used
    # because physical slots are global objects.
    if slot_type == 'logical':
        warn_db_default = True
    else:
        warn_db_default = False

    # Ensure psycopg libraries are available before connecting to DB:
    ensure_required_libs(module)
    conn_params = get_conn_params(module, module.params, warn_db_default=warn_db_default)
    db_connection, dummy = connect_to_db(module, conn_params, autocommit=True)
    cursor = db_connection.cursor(**pg_cursor_args)

    ##################################
    # Create an object and do main job
    pg_slot = PgSlot(module, cursor, name)

    changed = False

    if module.check_mode:
        if state == "present":
            if not pg_slot.exists:
                changed = True

            pg_slot.create(slot_type, immediately_reserve, output_plugin, just_check=True)

        elif state == "absent":
            if pg_slot.exists:
                changed = True
    else:
        if state == "absent":
            pg_slot.drop()

        elif state == "present":
            pg_slot.create(slot_type, immediately_reserve, output_plugin)

        changed = pg_slot.changed

    db_connection.close()
    module.exit_json(changed=changed, name=name, queries=pg_slot.executed_queries)


if __name__ == '__main__':
    main()
